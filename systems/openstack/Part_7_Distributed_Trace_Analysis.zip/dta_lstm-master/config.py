
DEFAULTS = {
    'threshold': .7,
    'top_k': 4,
    'epochs': 100,
    'batch_size': 50,
    'validation_split': 0.15,
    'explain': True,
    'gpus': 1,
    'span_list_col_name': 'span_list',
    'padding_symbol': 0
}
